print("semana 10: ejercicio 2")

A=input("ingrese el primer numero: ")
B=input("ingrese el segundo numero: ")
C=input("ingrese el tercer numero: ")

if A > B:
    if A > C:
        print("El mayor es:", A)
    else:
        print("El mayor es:", C)
elif A == B:
    if A > C:
        print("Los mayores son:", A, "y", B)
    elif A == C:
        print("Los tres valores son iguales")
    else:
        print("El mayor es:", C)
else:
    if B > C:
        print("El mayor es:", B)
    elif B == C:
        print("Los mayores son:", B, "y", C)
    else:
        print("El mayor es:", C)