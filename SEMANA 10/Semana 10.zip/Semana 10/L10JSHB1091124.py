print("Semana no. 10: Ejercicio 1")
mes=int(input("Ingrese un número entre 1 y 12: "))
if mes<1 or mes >12:
    print("Error: el número debe estar entre 1 y 12")
else: 
    #Validando
    if mes==1:
        print("Mes: enero")
    elif mes==2:
        print==("Mes: febrero")
    elif mes==3:
        print("Mes: marzo")
    else:
        print("Es otro mes")

    #validando con case
    match(mes):
        case 1:
            print("Mes: enero")
        case 2:
            print("Mes: febrero")
        case 3:
            print("Mes: marzo")
        case 4:
            print("Es otro mes")