print(" Semana 10, ejercicio: 3")

año=int(input("Ingrese su año de nacimiento: "))
if año <2025:
 mes=int(input("Ingrese su mes de nacimiento con números del 1 al 12: "))
else:
   print("Por favor ingrese una fecha válida")

if mes in range (1,13):
    día=int(input("Ingrese su fecha de nacimiento: "))
else:
    print("Error: el mes debe de estar entre 1 y 12")
if día in range (1,31):
    True
else:
    print("Ingrese una fecha válida, por favor")



if mes == 3:
   if día in range (21,32):
      print("Tu signo zodiacal es: Aries")
if mes==4:
   if día in range (1,20):
      print("Tu signo zodiacal es: Aries")

if mes==4:
   if día in range(20,31):
      print("Tu signo zodiacal es: Tauro")
if mes==5:
   if día in range (1,21):
      print("Tu signo zodiacal es: Tauro")

if mes==5:
   if día in range(21,32):
      print("Tu signo zodiacal es: Géminis")
if mes==6:
   if día in range (1,21):
      print("Tu signo zodiacal es: Géminis")

if mes==6:
   if día in range(21,31):
      print("Tu signo zodiacal es: Cancer")
if mes==7:
   if día in range(1,23):
      print("Tu signo zodiacal es: Cancer")

if mes==7:
   if día in range(23,32):
      print("Tu signo zodiacal es: Leo")
if mes==8:
   if día in range (1,23):
      print("Tu signo zodiacal es: Leo")

if mes==8:
   if día in range(23,32):
      print("Tu signo zodiacal es: Virgo")
if mes==9:
   if día in range(1,23):
      print("Tu signo zodiacal es: Virgo")

if mes==9:
   if día in range(23,31):
      print("Tu signo zodiacal es: Libra")
if mes==10:
   if día in range(1,23):
      print("Tu signo zodiacal es: Libra")

if mes==10:
   if día in range (23,32):
      print("Tu signo zodiacal es: Escorpio")
if mes==11:
   if día in range(1,22):
      print("Tu signo zodiacal es: Escorpio")

if mes==11:
   if día in range(22,31):
      print("Tu signo zodiacal es: Sagitario")
if mes==12:
   if día in range(1,22):
      print("Tu signo zodiacal es: Sagitario")

if mes==12:
   if día	in range(22,32):
      print("Tu signo zodiacal es: Capricornio")
if mes==1:
   if día in range(1,20):
       print("Tu signo zodiacal es: Capricornio")
      
if mes==1:
 if día in range(20,32):
    print("Tu signo zodiacal es: Acuario")
if mes==2:
  if día in range (1,19):
    print("Tu signo zodiacal es: Acuario")

if mes ==2:
   if día in range (19,29):
      print("Tu signo zodiacal es: Piscis")
if mes ==3:
   if día in range (1,21):
      print("Tu signo zodiacal es: Piscis")